package Java11Assignments;

public interface SimpleInterestInterface {
Double SI(Long a,int c,int b);
}
